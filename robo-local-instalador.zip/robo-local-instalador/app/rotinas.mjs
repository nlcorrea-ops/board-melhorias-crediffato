// Lista FECHADA de rotinas: o robô só abre estes endereços e só roda o código recebido nestas páginas.
// pronto = elemento que prova que a tela certa abriu (sem ele, a rotina não roda).
import {ROTINAS_CONSUMO} from './consumo.mjs';

export const ROTINAS = {
  ...ROTINAS_CONSUMO,
  // Indicadores Voz: CRM → Call Center → Relatórios → Análise de agentes (tela 505)
  indVoz: {url: 'https://crediffato.smartnx.io/crm/index.php?codmodulo=505', pronto: 'input[agente]'}
};
