// Consumo: contas puras (testadas) + as ações que o robô faz em cada site (mapeamento 14–16/11, spec §10).
// Tudo devolve só contagens/segundos/{d, ref, falha}: telefone, CPF e nome nunca saem daqui.
import fs from 'node:fs';

const num = v => Number(v) || 0;
const sem = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').trim().toLowerCase();
const isoDe = s => { const t = String(s || '').trim(); let m = t.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) return `${m[1]}-${m[2]}-${m[3]}`; m = t.match(/^(\d{2})\/(\d{2})\/(\d{4})/); return m ? `${m[3]}-${m[2]}-${m[1]}` : null; };
// CSV com ";" e aspas (formato dos exports do CRM/SipPulse)
const linhasCsv = txt => String(txt).split(/\r?\n/).filter(l => l.trim()).map(l => { const out = []; let cur = '', q = false;
  for (const c of l) { if (c === '"') q = !q; else if (c === ';' && !q) { out.push(cur.trim()); cur = ''; } else cur += c; } out.push(cur.trim()); return out; });

// WhatsApp = canal 12 + 2 (Parceiro); Webchat Plus = receptivos 11; E-mail = receptivos 15
export function somaMetrics(c) {
  const g = (id, k) => num(c[id] && c[id][k]);
  return {whatsRobo: g(12, 'bot_messages') + g(2, 'bot_messages'), whatsHumano: g(12, 'human_messages') + g(2, 'human_messages'), webchat: g(11, 'receptive'), email: g(15, 'receptive')};
}

// linhas = [[template_category, broker_status_name]]; não elegível = "Falha no disparo" (decisão do usuário 16/11)
export function contaHsm(linhas) {
  const r = {mkt: 0, util: 0, naoEleg: 0, outros: 0};
  for (const [cat, st] of linhas) { if (st === 'Falha no disparo') r.naoEleg++; else if (cat === 'Marketing') r.mkt++; else if (cat === 'Utility') r.util++; else r.outros++; }
  return r;
}

// linhas = [[categoria, status, diaDaSemana 0=dom]] → por dia da semana: elegíveis e respondidos (para a sugestão do orçamento)
export function respPorSemana(linhas) {
  const r = Array.from({length: 7}, () => ({elig: 0, resp: 0}));
  for (const [, st, dow] of linhas) { if (st === 'Falha no disparo' || !(dow >= 0 && dow <= 6)) continue; r[dow].elig++; if (st === 'Respondido') r[dow].resp++; }
  return r;
}

// linhas da "Lista Consumo Total" do SipPulse (Origem, Serviço, Tipo de Ligação, Duração, Preço)
export function resumoSipAtivo(linhas) {
  const r = {fixo: '00:00:00', movel: '00:00:00'};
  for (const l of linhas) { const t = sem(l[2]); if (t.startsWith('fixo')) r.fixo = l[3]; else if (t.startsWith('movel')) r.movel = l[3]; }
  return r;
}

// CSV das Entrantes: ORIGEM;DESTINO;DATA;DURACAO(SEG);TARIFA;TOTAL;SERVIÇO → segundos por dia e tipo
export function receptivoPorDia(csv) {
  const dias = new Map();
  for (const [orig, , data, dur, tar] of linhasCsv(csv).slice(1)) {
    const d = isoDe(data); if (!d) continue;
    const t = num(String(tar).replace(',', '.')), dig = String(orig).replace(/\D/g, '').replace(/^55(?=\d{10,11}$)/, '');
    const tipo = Math.abs(t - 0.12) < 0.001 ? 'fixo' : Math.abs(t - 0.24) < 0.001 ? 'movel' : dig.length === 10 ? 'fixo' : dig.length === 11 ? 'movel' : 'outro';
    if (!dias.has(d)) dias.set(d, {d, fixoSeg: 0, movelSeg: 0, outros: 0});
    const x = dias.get(d); if (tipo === 'outro') x.outros++; else x[tipo + 'Seg'] += num(dur);
  }
  return [...dias.values()].sort((a, b) => a.d < b.d ? -1 : 1);
}

// CSV do Exportar do relatório de chamadas do CRM → mesma regra do parseSms() do painel
export function smsLinhas(csv) {
  const [cab, ...rows] = linhasCsv(csv), h = cab.map(sem);
  const iT = h.indexOf('tipo'), iR = h.indexOf('referencia'), iS = h.indexOf('status chamada'), iF = h.indexOf('data/hora termino'), iI = h.indexOf('data/hora inicio');
  const out = [];
  for (const r of rows) {
    if (iT >= 0 && r[iT] && sem(r[iT]) !== 'sms') continue;
    const d = isoDe(iF >= 0 && r[iF] ? r[iF] : iI >= 0 ? r[iI] : ''); if (!d) continue;
    out.push({d, ref: num(String(r[iR] || '').replace(',', '.')), falha: iS >= 0 && sem(r[iS]).includes('falha')});
  }
  return out;
}

// ---------------- ações nos sites (rodam no Edge do robô) ----------------
const br = iso => iso.split('-').reverse().join('/');
const API = 'https://api-nxsuite.smartnx.io';

// Metrics: totais por canal (Billing) e HSM (Disparos, paginado de 5000) — só pelo realizado
async function acaoMetrics(page, cfg) {
  const p = cfg.realizado;
  const dados = await page.evaluate(async ({p, API}) => {
    const q = `initial_date=${p.ini}&final_date=${p.fim}&initial_hour=00%3A00%3A00.000&final_hour=23%3A59%3A59.999`;
    const get = async u => { const r = await fetch(u, {credentials: 'include'}); if (r.status === 401 || r.status === 403) throw new Error('sessão do Metrics expirada'); if (!r.ok) throw new Error('Metrics respondeu ' + r.status); return r.json(); };
    const porCanal = {};
    for (const id of [2, 11, 12, 15]) { window.__roboProgresso = 'Metrics: canal ' + id; porCanal[id] = (await get(`${API}/billing-api/billing/amount-chats?${q}&channel_id=${id}`))[0] || {}; }
    const hsm = []; let tp = 1;
    for (let pg = 1; pg <= tp; pg++) {
      window.__roboProgresso = `Metrics: HSM página ${pg} de ${tp}`;
      const j = await get(`${API}/report-api/report/hsm?${q}&page=${pg}&limit=5000`); tp = j.totalPages || 1;
      for (const r of j.result || []) hsm.push([r.template_category, r.broker_status_name, r.created_at ? new Date(r.created_at).getDay() : -1]);
    }
    return {porCanal, hsm};
  }, {p, API});
  return {...somaMetrics(dados.porCanal), hsm: contaHsm(dados.hsm), respSemana: respPorSemana(dados.hsm)};
}

// o CRM só busca até 7 dias por vez → período em blocos de no máximo 7 dias
export function blocos7(p) {
  const f = x => x.toISOString().slice(0, 10), d = new Date(p.ini + 'T00:00:00Z'), fim = new Date(p.fim + 'T00:00:00Z'), out = [];
  while (d <= fim) { const b = new Date(d); b.setUTCDate(b.getUTCDate() + 6); out.push({ini: f(d), fim: f(b < fim ? b : fim)}); d.setUTCDate(d.getUTCDate() + 7); }
  return out;
}

// CRM: para cada bloco de 7 dias, busca SMS (grava o filtro na sessão) e lê o mesmo CSV do botão Exportar
async function acaoSms(page, cfg, atualiza) {
  const linhas = [], bl = blocos7(cfg.realizado);
  for (const [i, p] of bl.entries()) {
    atualiza({progresso: `SMS: semana ${i + 1} de ${bl.length} (${br(p.ini)} a ${br(p.fim)})`});
    await page.evaluate(({di, df}) => {
      const s = document.getElementById('tipo_chamada'); s.value = 'SMS'; s.dispatchEvent(new Event('change', {bubbles: true}));
      for (const [id, v] of [['filtro_datai', di], ['filtro_horai', '00:00'], ['filtro_dataf', df], ['filtro_horaf', '23:59']]) { const e = document.getElementById(id); e.value = v; e.dispatchEvent(new Event('change', {bubbles: true})); }
    }, {di: br(p.ini), df: br(p.fim)});
    const resp = page.waitForResponse(r => r.url().includes('ModRelChamadasLead/carregardados.php'), {timeout: 120000});
    await page.click('#btn_pesquisar'); await resp;
    const csv = await page.evaluate(async () => new TextDecoder('latin1').decode(await (await fetch('modulos/ModRelChamadasLead/excel.php', {credentials: 'include'})).arrayBuffer()));
    linhas.push(...smsLinhas(csv));
  }
  return {linhas};
}

// SipPulse: datas por JS + clique real. Ativo: SEM "Exibir Detalhes" (resumo por tipo); Receptivo: COM (senão o Exportar fica desabilitado)
async function gerarSip(page, form, p, detalhes = false) {
  await page.evaluate(({form, di, df, detalhes}) => {
    for (const [id, v] of [[form + ':datefromInputDate', di], [form + ':datetoInputDate', df]]) { const e = document.getElementById(id); e.value = v; e.dispatchEvent(new Event('change', {bubbles: true})); }
    const cb = document.getElementById(form + ':displayDetails'); if (cb && cb.checked !== detalhes) cb.click();
  }, {form, di: br(p.ini), df: br(p.fim), detalhes});
}

async function acaoSipAtivo(page, cfg) {
  const out = {};
  for (const k of ['realizado', 'janela']) {
    if (!cfg[k]) { out[k] = null; continue; }
    await gerarSip(page, 'frmCdr', cfg[k]);
    const resp = page.waitForResponse(r => r.url().includes('usercall.jsf') && r.request().method() === 'POST', {timeout: 120000});
    await page.click('input[type=submit][value="Gerar Relatório"]'); await resp; await page.waitForTimeout(800);
    const linhas = await page.evaluate(() => { const tb = [...document.querySelectorAll('table')].filter(t => /Lista Consumo Total/.test(t.innerText)).pop();
      return tb ? [...tb.querySelectorAll('tr')].map(r => [...r.children].map(td => td.innerText.trim())).filter(c => c.length === 5) : []; });
    if (!linhas.length) throw new Error('SipPulse: não apareceu a "Lista Consumo Total" das Saintes');
    out[k] = resumoSipAtivo(linhas);
  }
  return out;
}

// Entrantes: Exportar para CSV → espera o arquivo novo em "Arquivos Exportados" (≤ 3 min) → baixa → lê → apaga o temporário.
// Clica SÓ no link de download (title "...download..."); a lixeira (title "...excluir...") nunca.
async function acaoSipRec(page, cfg, atualiza) {
  const nomes = () => page.evaluate(() => [...document.querySelectorAll('tr')].map(r => (r.innerText.match(/\d{14}-[\w.-]+\.csv/) || [])[0]).filter(Boolean));
  // Arquivos Exportados ordenado por "Data de Geração" do mais novo para o mais velho (clica no título até a ordem ficar decrescente)
  const abaArquivos = async () => {
    await page.locator('text=Arquivos Exportados').first().click(); await page.waitForTimeout(1500);
    for (let i = 0; i < 3; i++) {
      const n = await nomes(); if (n.length < 2 || n[0] >= n[n.length - 1]) break;
      await page.locator('text=Data de Geração').first().click(); await page.waitForTimeout(1500);
    }
  };
  // a aba "Arquivos Exportados" já aberta NÃO recarrega a lista ao ser clicada: recarrega a página do relatório antes de olhar
  const url = page.url(), recarrega = async () => { await page.goto(url, {waitUntil: 'domcontentloaded'}); await page.waitForLoadState('networkidle').catch(() => {}); };
  const listaNova = async () => { await recarrega(); await abaArquivos(); };
  const posta = () => page.waitForResponse(r => r.url().includes('usercalldid0800.jsf') && r.request().method() === 'POST', {timeout: 15000});
  const out = {};
  for (const k of ['realizado', 'janela']) {
    if (!cfg[k]) { out[k] = null; continue; }
    await listaNova(); const antes = new Set(await nomes());
    await recarrega();   // volta para a aba do relatório, limpa
    await gerarSip(page, 'frmCdrDid0800', cfg[k], true);
    // passo do usuário: Exibir Detalhes → Gerar Relatório → Exportar CSV → Arquivos Exportados → baixar o mais recente
    const resp = page.waitForResponse(r => r.url().includes('usercalldid0800.jsf') && r.request().method() === 'POST', {timeout: 120000});
    await page.click('input[type=submit][value="Gerar Relatório"]'); await resp;
    await page.waitForLoadState('networkidle').catch(() => {}); await page.waitForTimeout(1000);   // tela termina de redesenhar antes do Exportar
    // Exportar: confirma que o pedido chegou ao SipPulse; se não chegar em 15 s, clica de novo (uma vez só)
    let foi = false;
    for (let tent = 0; tent < 2 && !foi; tent++) {
      const ok = posta();
      await page.locator('input[type=submit][value="Exportar para CSV"]:not([disabled])').click({timeout: 60000});
      foi = await ok.then(() => true, () => false);
    }
    if (!foi) throw new Error('SipPulse: o clique em "Exportar para CSV" não foi aceito (2 tentativas)');
    let novo = null; const t0 = Date.now();
    while (!novo && Date.now() - t0 < 180000) {
      atualiza({progresso: `SipPulse: esperando o CSV do ${k} (${Math.round((Date.now() - t0) / 1000)} s)`});
      await page.waitForTimeout(Date.now() - t0 < 1000 ? 1500 : 2000); await listaNova();   // o CSV sai quase na hora
      const topo = (await nomes())[0]; novo = topo && !antes.has(topo) ? topo : null;   // o mais recente (1º da lista), e só se for novo
    }
    if (!novo) throw new Error('SipPulse: o CSV exportado não apareceu em 3 minutos (Arquivos Exportados)');
    const baixa = page.waitForEvent('download', {timeout: 120000});
    await page.locator('tr', {hasText: novo}).locator('a[title*="download"]').first().click();
    const arq = await (await baixa).path();
    try { out[k] = receptivoPorDia(fs.readFileSync(arq, 'latin1')); } finally { fs.rmSync(arq, {force: true}); }
  }
  return out;
}

const quemSip = async page => ((await page.locator('body').innerText().catch(() => '')).match(/Bem vindo,\s*([\w.-]+)@/) || [])[1] || null;
const SIP = 'http://nxvoip.smartnx.io:8080/SipPulsePortal/pages/reports/';
export const ROTINAS_CONSUMO = {
  consMetrics: {url: 'https://metrics.smartnx.io/metrics/billing', loginHosts: ['nxsuite.smartnx.io'], loginUrl: 'https://nxsuite.smartnx.io/',
    logado: page => page.evaluate(async () => (await fetch('https://api-nxsuite.smartnx.io/auth-api/user/info', {credentials: 'include'})).ok), pronto: 'text=Quadro Financeiro', acao: acaoMetrics},
  consSms: {url: 'https://crediffato.smartnx.io/crm/index.php?codmodulo=389', pronto: '#btn_pesquisar', acao: acaoSms},
  consSipAtivo: {url: SIP + 'usercall.jsf', loginUrl: SIP.replace('reports/', 'login/login.jsf'), pronto: '[id="frmCdr:datefromInputDate"]', conta: 'ativo', quemLogado: quemSip, sair: 'a:has-text("Sair")', acao: acaoSipAtivo},
  consSipRec: {url: SIP + 'usercalldid0800.jsf', loginUrl: SIP.replace('reports/', 'login/login.jsf'), pronto: '[id="frmCdrDid0800:datefromInputDate"]', conta: 'rec', quemLogado: quemSip, sair: 'a:has-text("Sair")', acao: acaoSipRec}
};
