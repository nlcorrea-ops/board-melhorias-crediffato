// Robô local do Painel Central Crediffato.
// Escuta só em 127.0.0.1, exige a chave (Bearer) e roda UMA tarefa por vez (fila).
// Rotas: GET /parear (sem chave: só o painel liberado, entrega a chave) · GET /status · POST /rodar {rotina, codigo, cfg} → {id} · GET /tarefa/:id
// Estados de uma tarefa: fila | rodando | precisa_login | concluida | erro
import http from 'node:http';
import crypto from 'node:crypto';

const VERSAO = 2, GUARDA_MS = 30 * 60 * 1000;   // tarefas terminadas ficam 30 min para o painel ler

export function criarServidor({token, executor, porta, rotinas, origens = [], avisoOrigem = null, semCodigo = [], sites = [], salvarCredencial = null}) {
  const tarefas = new Map(), fila = [];
  let rodando = null;

  const publica = t => ({id: t.id, rotina: t.rotina, estado: t.estado, progresso: t.progresso,
    ...(t.estado === 'concluida' ? {resultado: t.resultado} : {}), ...(t.estado === 'erro' ? {erro: t.erro} : {}),
    ...(t.estado === 'precisa_login' && t.pedeSenha ? {pedeSenha: t.pedeSenha} : {})});

  async function proxima() {
    if (rodando || !fila.length) return;
    const t = fila.shift(); rodando = t.id; t.estado = 'rodando';
    const atualiza = ({estado, progresso, pedeSenha} = {}) => { if (estado) t.estado = estado; if (progresso !== undefined) t.progresso = progresso; if (pedeSenha !== undefined) t.pedeSenha = pedeSenha; };
    try { t.resultado = await executor(t, atualiza); t.estado = 'concluida'; }
    catch (e) { t.estado = 'erro'; t.erro = String((e && e.message) || e); }
    finally { t.fim = Date.now(); rodando = null; setTimeout(() => tarefas.delete(t.id), GUARDA_MS).unref(); proxima(); }
  }

  // painel aberto do disco (file://, origem "null"), localhost (testes) e as origens liberadas (painel hospedado). Outro site recebe "null" (o navegador bloqueia).
  const corsDe = req => {
    const o = req.headers.origin || 'null';
    return {
      'Access-Control-Allow-Origin': /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(o) || origens.includes(o) ? o : 'null',
      'Access-Control-Allow-Headers': 'Authorization, Content-Type',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Private-Network': 'true',
      'Vary': 'Origin'
    };
  };
  const responde = (res, status, corpo) => { res.writeHead(status, {...res.cors, 'Content-Type': 'application/json; charset=utf-8'}); res.end(corpo === undefined ? '' : JSON.stringify(corpo)); };
  const iguais = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
  const lerCorpo = req => new Promise((ok, erro) => { let s = ''; req.on('data', c => { s += c; if (s.length > 5e6) { erro(new Error('corpo grande demais')); req.destroy(); } }); req.on('end', () => ok(s)); req.on('error', erro); });

  const servidor = http.createServer(async (req, res) => {
    res.cors = corsDe(req);   // por resposta: pedidos simultâneos não se misturam
    if (avisoOrigem && req.headers.origin && res.cors['Access-Control-Allow-Origin'] !== req.headers.origin) avisoOrigem(req.headers.origin);   // página de fora (o navegador vai barrar): registra a origem para diagnóstico
    if (req.method === 'OPTIONS') { res.writeHead(204, res.cors); return res.end(); }
    // pareamento: o painel hospedado (origem exata da lista) pega a chave sozinho. Nunca para origem null/localhost/outro site,
    // e só se o Host for o próprio PC (barra site que aponta o domínio dele para 127.0.0.1)
    if (req.method === 'GET' && req.url === '/parear') {
      const hostOk = /^(127\.0\.0\.1|localhost)(:\d+)?$/.test(req.headers.host || '');
      return hostOk && origens.includes(req.headers.origin) ? responde(res, 200, {token, versao: VERSAO}) : responde(res, 403, {erro: 'pareamento só pelo painel'});
    }
    if (!iguais(req.headers.authorization || '', 'Bearer ' + token)) return responde(res, 401, {erro: 'chave do robô ausente ou errada'});
    const url = new URL(req.url, 'http://127.0.0.1');
    try {
      if (req.method === 'GET' && url.pathname === '/status') return responde(res, 200, {versao: VERSAO, rodando, fila: fila.length});
      if (req.method === 'POST' && url.pathname === '/rodar') {
        const {rotina, codigo, cfg} = JSON.parse(await lerCorpo(req) || '{}');
        if (!rotinas.includes(rotina)) return responde(res, 400, {erro: 'rotina desconhecida: ' + rotina});
        if (!semCodigo.includes(rotina) && (typeof codigo !== 'string' || !codigo.trim())) return responde(res, 400, {erro: 'código da rotina ausente'});
        const t = {id: crypto.randomUUID(), rotina, codigo, cfg: cfg || {}, estado: 'fila', progresso: '', criada: Date.now()};
        tarefas.set(t.id, t); fila.push(t); proxima();
        return responde(res, 200, {id: t.id});
      }
      // senha nova vinda da janelinha do painel: grava no cofre local (só para site das rotinas); nunca é devolvida nem registrada no log
      if (req.method === 'POST' && url.pathname === '/credencial') {
        const {host, usuario, senha} = JSON.parse(await lerCorpo(req) || '{}');
        if (!salvarCredencial || !sites.includes(host)) return responde(res, 400, {erro: 'site fora das rotinas do robô'});
        if (typeof usuario !== 'string' || !usuario.trim() || typeof senha !== 'string' || !senha) return responde(res, 400, {erro: 'usuário e senha são obrigatórios'});
        salvarCredencial(host, usuario.trim(), senha);
        return responde(res, 200, {ok: true, host});
      }
      const m = url.pathname.match(/^\/tarefa\/([\w-]+)$/);
      if (req.method === 'GET' && m) { const t = tarefas.get(m[1]); return t ? responde(res, 200, publica(t)) : responde(res, 404, {erro: 'tarefa não encontrada'}); }
      return responde(res, 404, {erro: 'rota desconhecida'});
    } catch (e) { return responde(res, 400, {erro: String(e.message || e)}); }
  });
  servidor.listen(porta, '127.0.0.1');
  return {servidor, fila, tarefas};
}

// ---- main: só quando rodado direto ("Iniciar robô.cmd" → node servidor.mjs) ----
import {fileURLToPath, pathToFileURL} from 'node:url';
import path from 'node:path';
import fs from 'node:fs';
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const PASTA = path.dirname(fileURLToPath(import.meta.url)), PORTA = 47823;
  const log = msg => { const l = new Date().toLocaleString('pt-BR') + '  ' + msg; console.log(l); try { fs.appendFileSync(path.join(PASTA, 'log.txt'), l + '\n'); } catch {} };
  const {lerOuCriarToken} = await import('./token.mjs');
  const {abrirNavegador} = await import('./navegador.mjs');
  const {criarExecutor} = await import('./executor.mjs');
  const {ROTINAS} = await import('./rotinas.mjs');
  const {lerCredencial, salvarCredencial, PASTA_LOCAL} = await import('./credenciais.mjs');
  const token = lerOuCriarToken(path.join(PASTA, 'token.txt'));
  // sessão do Edge do robô fica só neste PC (fora do OneDrive)
  // o Edge do robô só abre quando chega um pedido; se a janela for fechada, o robô continua no ar e reabre no próximo
  let ctx = null, abrindo = null;
  const navegador = async () => {
    if (ctx) return ctx;
    if (!abrindo) abrindo = abrirNavegador({perfil: path.join(PASTA_LOCAL, 'perfil'), visivel: true}).then(c => {
      ctx = c; abrindo = null;
      c.on('close', () => { ctx = null; log('janela do robô fechada (ela reabre no próximo pedido)'); });
      return c;
    }, e => { abrindo = null; throw e; });
    return abrindo;
  };
  const executa = criarExecutor({ctx: navegador, rotinas: ROTINAS, credencial: host => lerCredencial(host)});
  // o log guarda só rotina, estado e duração: nada de dado de cliente
  const executor = async (t, atualiza) => {
    const t0 = Date.now(); log(`▶ ${t.rotina} começou`);
    try { const r = await executa(t, atualiza); log(`✔ ${t.rotina} terminou em ${Math.round((Date.now() - t0) / 1000)} s`); return r; }
    catch (e) { log(`✖ ${t.rotina} erro: ${(e && e.message) || e}`); throw e; }
  };
  const vistas = new Set();
  // painel hospedado do usuário (GitHub Pages); a chave continua obrigatória
  const {servidor} = criarServidor({token, executor, porta: PORTA, origens: ['https://nlcorrea-ops.github.io'], avisoOrigem: o => { if (!vistas.has(o)) { vistas.add(o); log('pedido recusado vindo de ' + o); } }, rotinas: Object.keys(ROTINAS), semCodigo: Object.keys(ROTINAS).filter(k => ROTINAS[k].acao),
    sites: [...new Set(Object.values(ROTINAS).map(r => new URL(r.url).host + (r.conta ? '#' + r.conta : '')))],
    salvarCredencial: (h, u, s) => { salvarCredencial(h, u, s); log('senha nova guardada para ' + h); }});
  servidor.on('error', async e => { log(e.code === 'EADDRINUSE' ? 'o robô já está aberto (porta ' + PORTA + ' ocupada); fechando esta cópia' : 'erro no servidor: ' + e.message); if (ctx) await ctx.close().catch(() => {}); process.exit(1); });
  servidor.on('listening', () => log(`robô local pronto em http://127.0.0.1:${PORTA} · rotinas: ${Object.keys(ROTINAS).join(', ')}`));
  const fecha = async () => { log('encerrando'); if (ctx) await ctx.close().catch(() => {}); process.exit(0); };
  process.on('SIGINT', fecha); process.on('SIGTERM', fecha);
}
