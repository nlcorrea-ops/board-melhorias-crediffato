// Edge do robô: perfil próprio (as sessões de login ficam aqui, nenhuma senha é guardada pelo robô).
// Usa o Microsoft Edge instalado no PC (channel 'msedge'); a biblioteca não baixa navegador.
import {chromium} from 'playwright-core';

export async function abrirNavegador({perfil, visivel}) {
  return chromium.launchPersistentContext(perfil, {
    channel: 'msedge',
    headless: !visivel,
    acceptDownloads: true,
    viewport: null,
    args: visivel ? ['--start-minimized'] : []
  });
}

// Uma aba por site: se já existe aba aberta no mesmo host, reaproveita; senão abre outra.
export async function paginaDaRotina(ctx, url) {
  const host = new URL(url).host;
  let p = ctx.pages().find(pg => { try { return new URL(pg.url()).host === host; } catch { return false; } });
  if (!p) p = ctx.pages().find(pg => pg.url() === 'about:blank') || await ctx.newPage();
  await p.goto(url, {waitUntil: 'domcontentloaded'});
  return p;
}
