// Cadastrar login: guarda usuário + senha de um site no cofre local do robô (criptografado, fora do OneDrive).
// A senha é digitada aqui (aparece como ****) e não vai para nenhum outro lugar.
import readline from 'node:readline/promises';
import {ROTINAS} from './rotinas.mjs';
import {salvarCredencial, removerCredencial, listarCredenciais, PASTA_LOCAL} from './credenciais.mjs';

const sites = [...new Set(Object.values(ROTINAS).map(r => new URL(r.url).host + (r.conta ? '#' + r.conta : '')))];

function senhaOculta(pergunta) {
  return new Promise(ok => {
    const e = process.stdin; process.stdout.write(pergunta);
    e.setRawMode(true); e.resume(); e.setEncoding('utf8');
    let v = '';
    const lê = txt => {
      for (const c of txt) {
        if (c === '\r' || c === '\n') { e.setRawMode(false); e.pause(); e.off('data', lê); process.stdout.write('\n'); return ok(v); }
        if (c === '\u0003') { process.stdout.write('\n'); process.exit(1); }
        if (c === '\b' || c === '\x7f') { if (v) { v = v.slice(0, -1); process.stdout.write('\b \b'); } continue; }
        v += c; process.stdout.write('*');
      }
    };
    e.on('data', lê);
  });
}

const rl = readline.createInterface({input: process.stdin, output: process.stdout});
console.log('\n=== Cadastrar login do robô ===');
const ja = listarCredenciais();
console.log('Já cadastrados: ' + (ja.length ? ja.join(', ') : 'nenhum'));
console.log('\nSites das rotinas:');
sites.forEach((s, i) => console.log(`  ${i + 1}) ${s}`));
console.log('  R) remover um cadastro');
const op = (await rl.question('\nEscolha o número: ')).trim();
if (/^r$/i.test(op)) {
  const h = (await rl.question('Site para remover (como aparece na lista acima): ')).trim();
  removerCredencial(h); console.log('Removido: ' + h); rl.close(); process.exit(0);
}
const site = sites[Number(op) - 1];
if (!site) { console.log('Opção inválida.'); rl.close(); process.exit(1); }
const usuario = (await rl.question(`Usuário em ${site}: `)).trim();
rl.close();
const senha = await senhaOculta('Senha (aparece como ****): ');
if (!usuario || !senha) { console.log('Usuário ou senha vazio: nada foi gravado.'); process.exit(1); }
salvarCredencial(site, usuario, senha);
console.log(`\nPronto: login de ${site} guardado criptografado em ${PASTA_LOCAL}`);
console.log('Na próxima vez que o site pedir login, o robô entra sozinho.');
