// Períodos do Consumo (regra do usuário, 14/11/2026). A MESMA função está colada no painel (script ROBO LOCAL): mudou aqui, muda lá.
// realizado = dia 01 até ontem (null no dia 01). janela (previsão do VoIP) = os N dias que faltam (hoje..fim do mês),
// tirados do mês anterior alinhados pelo dia da semana: termina na última ocorrência, no mês anterior, do dia da semana
// do último dia do mês atual. fechamento 'AAAA-MM' = mês inteiro, sem janela.
export function periodos(hoje, fechamento) {
  const p = n => String(n).padStart(2, '0'), f = x => `${x.getFullYear()}-${p(x.getMonth() + 1)}-${p(x.getDate())}`;
  if (fechamento) {
    const [a, m] = fechamento.split('-').map(Number);
    return {realizado: {ini: f(new Date(a, m - 1, 1)), fim: f(new Date(a, m, 0))}, janela: null};
  }
  const a = hoje.getFullYear(), m = hoje.getMonth(), d = hoje.getDate(), ultimo = new Date(a, m + 1, 0);
  const fim = new Date(a, m, 0);   // último dia do mês anterior; recua até cair no mesmo dia da semana
  while (fim.getDay() !== ultimo.getDay()) fim.setDate(fim.getDate() - 1);
  const ini = new Date(fim); ini.setDate(fim.getDate() - (ultimo.getDate() - d));
  return {realizado: d > 1 ? {ini: f(new Date(a, m, 1)), fim: f(new Date(a, m, d - 1))} : null, janela: {ini: f(ini), fim: f(fim)}};
}
