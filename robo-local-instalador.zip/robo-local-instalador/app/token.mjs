// Chave do robô: criada uma vez (32 bytes aleatórios, em hexadecimal) e guardada em token.txt.
// O painel manda essa chave em toda chamada; sem ela o robô responde 401.
import fs from 'node:fs';
import crypto from 'node:crypto';

export function lerOuCriarToken(arquivo) {
  try { const t = fs.readFileSync(arquivo, 'utf8').trim(); if (/^[0-9a-f]{64}$/.test(t)) return t; } catch {}
  const t = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(arquivo, t + '\n');
  return t;
}
