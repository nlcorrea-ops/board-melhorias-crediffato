// Executor: abre a tela da rotina no Edge do robô, entra sozinho com o login do cofre (ou espera a pessoa),
// roda o código que o painel mandou (a mesma função do favorito, com cfg.modoRobo = true) e devolve o resultado.
import {paginaDaRotina} from './navegador.mjs';

const dorme = ms => new Promise(r => setTimeout(r, ms));
// só senha VISÍVEL conta como tela de login (o CRM tem campos "trocar senha" escondidos em todas as telas)
const SENHA_VISIVEL = 'input[type=password]:visible';

// espera até a tela certa (pronto) OU a tela de login aparecer; devolve 'pronto' | 'login' | null
async function qualTela(page, pronto, ms) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try {
      if (await page.locator(pronto).count()) return 'pronto';
      if (await page.locator(SENHA_VISIVEL).count()) return 'login';
    } catch { /* página navegando: tenta de novo */ }
    await dorme(250);
  }
  return null;
}

// Login automático: preenche usuário + senha do formulário que tem a senha visível e CLICA no botão de entrar
// (o CRM roda um script no botão "Entrar"; o Enter sozinho não vale). Sem botão, usa Enter.
async function entrarSozinho(page, cred) {
  const T = {timeout: 8000};
  const senha = page.locator(SENHA_VISIVEL).first();
  const form = senha.locator('xpath=ancestor::form[1]');
  const escopo = (await form.count()) ? form : page;
  const usuario = escopo.locator('input[type=text]:visible, input[type=email]:visible, input:not([type]):visible').first();
  if (await usuario.count()) await usuario.fill(cred.usuario, T);
  await senha.fill(cred.senha, T);
  const botoes = escopo.locator('button:visible, input[type=submit]:visible, input[type=button]:visible');
  const porTexto = botoes.filter({hasText: /entrar|acessar|login|logar|sign in/i});
  const botao = (await porTexto.count()) ? porTexto.first() : (await botoes.count()) ? botoes.first() : null;
  if (botao) await botao.click(T); else await senha.press('Enter', T);
}

// credencial(chave) → {usuario, senha} | null (cofre local); chave = host, ou host#conta quando o site tem várias contas (R.conta). Só é usada se a página de login estiver no MESMO site da rotina.
export function criarExecutor({ctx, rotinas, esperaLogin = 10 * 60 * 1000, intervaloProgresso = 1000, esperaAutoLogin = 20000, credencial = () => null}) {
  return async (t, atualiza) => {
    const R = rotinas[t.rotina];
    if (!R) throw new Error('rotina desconhecida: ' + t.rotina);
    const page = await paginaDaRotina(typeof ctx === 'function' ? await ctx() : ctx, R.url);
    // rede de segurança: alert/confirm/prompt nunca travam a página do robô
    if (!page.__roboDialogo) { page.on('dialog', d => d.dismiss().catch(() => {})); page.__roboDialogo = true; }

    const host = new URL(R.url).host, chave = R.conta ? host + '#' + R.conta : host;
    const lerCred = async () => { try { return await credencial(chave); } catch { return null; } };
    // SipPulse: sem sessão o relatório cai em "sessionexpired" (sem campo de senha) → abre a tela de login da rotina
    if (R.loginUrl && /expir/i.test(page.url())) await page.goto(R.loginUrl, {waitUntil: 'domcontentloaded'}).catch(() => {});
    let tela = await qualTela(page, R.pronto, 20000);
    // tela abre mas a sessão não vale (Metrics: página carrega, API recusa) → vai ao login
    if (tela === 'pronto' && R.logado && R.loginUrl && !(await R.logado(page).catch(() => false))) {
      await page.goto(R.loginUrl, {waitUntil: 'domcontentloaded'}).catch(() => {});
      tela = await qualTela(page, R.pronto, 20000);
    }
    // site com várias contas no mesmo endereço (SipPulse ativo x receptivo): logado em outra → sai antes (sem senha guardada também sai, para pedir a certa)
    if (tela === 'pronto' && R.conta && R.quemLogado) {
      const quem = await R.quemLogado(page).catch(() => null), c = await lerCred();
      if (quem && (!c || quem !== c.usuario)) {
        await page.locator(R.sair).first().click({timeout: 8000});
        await page.goto(R.loginUrl || R.url, {waitUntil: 'domcontentloaded'}).catch(() => {});   // SipPulse sem sessão = "expirada": vai direto ao login
        tela = await qualTela(page, R.pronto, 20000);
      }
    }
    if (tela === 'login') {
      // login no próprio site da rotina ou num endereço que ela libera (R.loginHosts: Metrics autentica no NX Suite)
      const noSite = () => { try { const h = new URL(page.url()).host; return h === host || (R.loginHosts || []).includes(h); } catch { return false; } };
      // pedeSenha: o painel abre a janelinha "senha nova" (só nesses endereços)
      const pede = (msg, motivo, usuario) => {
        atualiza({estado: 'precisa_login', progresso: msg, pedeSenha: motivo && noSite() ? {host: chave, motivo, usuario: usuario || ''} : null});
        page.bringToFront().catch(() => {});
      };
      let tentada = null, tentouEm = 0, usuarioAtual = '';   // cada senha é tentada UMA vez: senha errada repetida pode bloquear a conta
      const tenta = async cred => {
        tentada = JSON.stringify(cred); usuarioAtual = cred.usuario;
        atualiza({estado: 'rodando', progresso: 'entrando sozinho no site…', pedeSenha: null});
        try { await entrarSozinho(page, cred); tentouEm = Date.now(); }
        catch (e) { tentouEm = 0; pede('O login automático não conseguiu preencher a tela (' + String((e && e.message) || e).split(/\r?\n/)[0].slice(0, 120) + '). Entre no site na janela do robô.'); }
      };
      const c0 = await lerCred();
      if (c0 && noSite()) await tenta(c0);
      else if (noSite()) pede(`Sem senha guardada para ${host}: informe no painel (ou entre na janela do robô).`, 'sem-senha');
      else pede('Entre no site na janela do robô; ele continua sozinho.');
      const t0 = Date.now();
      while (tela !== 'pronto' && Date.now() - t0 < esperaLogin) {
        await dorme(intervaloProgresso);
        if (page.isClosed()) throw new Error('a janela do robô foi fechada no meio da rotina; clique em Rodar agora de novo');
        if (tentouEm && Date.now() - tentouEm > esperaAutoLogin) {
          tentouEm = 0;
          pede('A senha guardada não entrou (mudou?). Informe a senha nova no painel.', 'senha-errada', usuarioAtual);
        }
        let temSenha = 1;
        try { temSenha = await page.locator(SENHA_VISIVEL).count(); } catch {}
        if (!temSenha) {   // entrou: o site costuma cair no início, então volta para a tela da rotina
          await page.goto(R.url, {waitUntil: 'domcontentloaded'}).catch(() => {});
          tela = await qualTela(page, R.pronto, 20000);
        } else if (!tentouEm && noSite()) {   // senha nova chegou pelo painel? tenta uma vez
          const c = await lerCred();
          if (c && JSON.stringify(c) !== tentada) await tenta(c);
        }
      }
      if (tela !== 'pronto') throw new Error('o login não foi feito a tempo na janela do robô (' + new URL(R.url).host + ')');
      atualiza({estado: 'rodando', progresso: ''});
    } else if (tela !== 'pronto') {
      throw new Error(`a tela esperada não abriu (${R.url}): não achei ${R.pronto}`);
    }

    const cfg = {...(t.cfg || {}), modoRobo: true};
    const vigia = setInterval(async () => {
      try { const p = await page.evaluate('window.__roboProgresso || ""'); if (p) atualiza({progresso: String(p)}); } catch {}
    }, intervaloProgresso);
    try {
      // expressão avaliada pelo próprio navegador (não usa eval dentro da página: funciona mesmo com política de segurança do site)
      if (R.acao) return await R.acao(page, cfg, atualiza);   // rotina feita no robô (Consumo: clique real, download)
      return await page.evaluate(`(${t.codigo})(${JSON.stringify(cfg)})`);
    } catch (e) {
      throw new Error(String(e.message || e).replace(/^page\.evaluate:\s*(Error:\s*)?/, '').split('\n')[0]);
    } finally { clearInterval(vigia); }
  };
}
