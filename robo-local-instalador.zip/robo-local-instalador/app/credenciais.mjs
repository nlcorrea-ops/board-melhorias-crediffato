// Cofre de logins do robô: usuário e senha por site, criptografados (AES-256-GCM).
// Fica em %LOCALAPPDATA%\robo-local (só deste PC, FORA do OneDrive). A chave de criptografia fica ao lado, também só local.
// Ninguém vê a senha: ela é digitada no "Cadastrar login.cmd" e só o robô a usa, só no site cadastrado.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export const PASTA_LOCAL = path.join(process.env.LOCALAPPDATA || path.join(process.env.USERPROFILE || '.', 'AppData', 'Local'), 'robo-local');

const arqDados = p => path.join(p, 'credenciais.json');
function chave(p) {
  fs.mkdirSync(p, {recursive: true});
  const arq = path.join(p, 'chave.bin');
  if (!fs.existsSync(arq)) fs.writeFileSync(arq, crypto.randomBytes(32), {mode: 0o600});
  return fs.readFileSync(arq);
}
const ler = p => { try { return JSON.parse(fs.readFileSync(arqDados(p), 'utf8')); } catch { return {}; } };
const grava = (p, j) => { fs.mkdirSync(p, {recursive: true}); fs.writeFileSync(arqDados(p), JSON.stringify(j, null, 1), {mode: 0o600}); };

export function salvarCredencial(host, usuario, senha, p = PASTA_LOCAL) {
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', chave(p), iv);
  c.setAAD(Buffer.from(host));   // o registro só abre para o site em que foi gravado
  const dado = Buffer.concat([c.update(JSON.stringify({usuario, senha}), 'utf8'), c.final()]);
  const j = ler(p); j[host] = {iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), dado: dado.toString('base64'), em: new Date().toISOString()};
  grava(p, j);
}

export function lerCredencial(host, p = PASTA_LOCAL) {
  const r = ler(p)[host]; if (!r) return null;
  try {
    const d = crypto.createDecipheriv('aes-256-gcm', chave(p), Buffer.from(r.iv, 'base64'));
    d.setAAD(Buffer.from(host)); d.setAuthTag(Buffer.from(r.tag, 'base64'));
    return JSON.parse(Buffer.concat([d.update(Buffer.from(r.dado, 'base64')), d.final()]).toString('utf8'));
  } catch { return null; }
}

export function removerCredencial(host, p = PASTA_LOCAL) { const j = ler(p); delete j[host]; grava(p, j); }
export const listarCredenciais = (p = PASTA_LOCAL) => Object.keys(ler(p));
