@echo off
rem Instala (ou atualiza) o Robo local do Painel Central Crediffato neste PC, so para este usuario (sem admin).
rem Destino: %LOCALAPPDATA%\robo-local  (fora do OneDrive). Logins e chave antigos sao mantidos.
setlocal
chcp 65001 >nul
set "ORIGEM=%~dp0"
set "DEST=%LOCALAPPDATA%\robo-local"
set "SYS=%SystemRoot%\System32"
set "NODEVER=v22.23.5"
set "NODEHASH=4a191082e9706866830379d577d2cc8a50c776fcd9436a8d061b063ed0d9a0e3"
title Instalando o Robo local
echo.
echo  ==== Robo local - Painel Central Crediffato ====
echo.
if not exist "%ORIGEM%app\servidor.mjs" (
  echo  Nao achei a pasta "app" ao lado deste arquivo.
  echo  Extraia o .zip inteiro primeiro: botao direito no .zip, "Extrair tudo", e rode o instalador de dentro da pasta extraida.
  goto :fim
)

rem 1) fecha o robo antigo, se estiver aberto
"%SYS%\taskkill.exe" /FI "WINDOWTITLE eq Robo local*" /T /F >nul 2>&1

rem 2) copia o programa (token.txt e log.txt antigos ficam)
echo  [1/4] Copiando o robo...
if not exist "%DEST%\app" mkdir "%DEST%\app"
"%SYS%\xcopy.exe" "%ORIGEM%app" "%DEST%\app" /E /I /Y /Q >nul
if errorlevel 1 ( echo  Falhou ao copiar os arquivos. & goto :fim )

rem 3) Node (o motor do robo): usa o que ja tem; senao baixa o oficial do nodejs.org e confere a assinatura
echo  [2/4] Conferindo o Node...
if exist "%DEST%\node\node.exe" goto :node_ok
if not exist "%DEST%\node" mkdir "%DEST%\node"
if exist "%USERPROFILE%\Downloads\Ferramentas\node\node.exe" (
  copy /Y "%USERPROFILE%\Downloads\Ferramentas\node\node.exe" "%DEST%\node\node.exe" >nul
  goto :node_ok
)
echo        baixando o Node %NODEVER% de nodejs.org, uns 30 MB...
set "ZIP=%TEMP%\robo-node.zip"
set "TMPN=%TEMP%\robo-node"
"%SYS%\curl.exe" -fsSL --retry 2 -o "%ZIP%" "https://nodejs.org/dist/%NODEVER%/node-%NODEVER%-win-x64.zip"
if errorlevel 1 goto :node_falhou
"%SYS%\certutil.exe" -hashfile "%ZIP%" SHA256 | "%SYS%\findstr.exe" /i "%NODEHASH%" >nul
if errorlevel 1 ( echo        O arquivo baixado nao confere com o oficial. Nada foi instalado. & del "%ZIP%" & goto :fim )
if exist "%TMPN%" rmdir /S /Q "%TMPN%"
mkdir "%TMPN%"
"%SYS%\tar.exe" -xf "%ZIP%" -C "%TMPN%"
copy /Y "%TMPN%\node-%NODEVER%-win-x64\node.exe" "%DEST%\node\node.exe" >nul
del "%ZIP%"
rmdir /S /Q "%TMPN%"
if not exist "%DEST%\node\node.exe" goto :node_falhou
:node_ok

rem 4) atalhos: iniciar, cadastrar login, e (se quiser) ligar junto com o Windows
echo  [3/4] Criando os atalhos...
> "%DEST%\Iniciar robo.cmd" (
  echo @echo off
  echo cd /d "%DEST%\app"
  echo start "Robo local" /min "%DEST%\node\node.exe" servidor.mjs
)
> "%DEST%\Cadastrar login.cmd" (
  echo @echo off
  echo chcp 65001 ^>nul
  echo cd /d "%DEST%\app"
  echo "%DEST%\node\node.exe" cadastrar.mjs
  echo pause
)
set "MENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
copy /Y "%DEST%\Iniciar robo.cmd" "%MENU%\Robo local - iniciar.cmd" >nul
echo.
"%SYS%\choice.exe" /C SN /M "  Ligar o robo sozinho sempre que o Windows iniciar (recomendado)"
if errorlevel 2 (
  del "%MENU%\Startup\Robo local.cmd" >nul 2>&1
) else (
  copy /Y "%DEST%\Iniciar robo.cmd" "%MENU%\Startup\Robo local.cmd" >nul
)

echo  [4/4] Ligando o robo...
call "%DEST%\Iniciar robo.cmd"
echo.
echo  Pronto! O robo esta ligado, numa janela minimizada "Robo local".
echo  Volte ao painel e clique em "tentar de novo": ele conecta sozinho.
echo  Na primeira rotina, o painel pede o SEU usuario e senha de cada sistema;
echo  eles ficam so neste PC, criptografados.
goto :fim

:node_falhou
echo.
echo  Nao consegui baixar o Node - rede ou proxy da empresa?
echo  Baixe manualmente: https://nodejs.org/dist/%NODEVER%/node-%NODEVER%-win-x64.zip
echo  extraia, copie o node.exe para "%DEST%\node\" e rode este instalador de novo.

:fim
echo.
pause
